import fish_tank


def test_import():
    assert fish_tank
