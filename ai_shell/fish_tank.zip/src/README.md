# Console Fish Tank

## Usage

```shell
python -m fish_tank
```

## Testing

```shell
pytest tests
```

## TODO

- When shark is adjacent to fish, shark eats fish.
